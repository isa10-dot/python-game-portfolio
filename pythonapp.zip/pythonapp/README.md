# Isa's Game Portfolio Website

A modern, responsive web application built with Python Flask featuring a beautiful UI/UX design for showcasing game projects.

## Features

- **Modern UI/UX Design**: Clean, professional interface with smooth animations
- **Responsive Layout**: Optimized for all devices and screen sizes
- **Interactive Game Cards**: Click on cards to visit game project links
- **Header with Logo**: Features "Isa" branding with navigation menu
- **Multiple Pages**: Home, About, and Contact pages
- **Professional Styling**: Modern color scheme with gradients and shadows

## Project Structure

```
pythonapp/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/            # HTML templates
│   ├── base.html         # Base template with header/footer
│   ├── index.html        # Homepage with game cards
│   ├── about.html        # About page
│   └── contact.html      # Contact page
└── static/              # Static assets
    ├── css/
    │   └── style.css     # Custom CSS styles
    └── js/
        └── script.js     # JavaScript functionality
```

## Installation & Setup

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the application:**
   ```bash
   python app.py
   ```

3. **Open your browser and visit:**
   ```
   http://127.0.0.1:5000
   ```

## How to Use

1. **Homepage**: Browse through the featured game cards
2. **Click Cards**: Click on any game card to open the project link
3. **Navigation**: Use the header navigation to explore different pages
4. **Responsive**: The site works perfectly on desktop, tablet, and mobile

## Customization

### Adding New Games

Edit the `GAME_PROJECTS` list in `app.py`:

```python
GAME_PROJECTS = [
    {
        'id': 7,
        'title': 'Your New Game',
        'description': 'Description of your game',
        'image': 'game-image.jpg',
        'link': 'https://your-game-link.com',
        'tags': ['Genre1', 'Genre2']
    }
]
```

### Updating Links

Change the project links in the `GAME_PROJECTS` dictionary to point to your actual game repositories or websites.

### Styling

Modify `static/css/style.css` to customize:
- Colors and themes
- Layout and spacing
- Animations and effects
- Typography

## Technologies Used

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript
- **Styling**: Bootstrap 5, Custom CSS
- **Icons**: Font Awesome
- **Responsive**: Mobile-first design

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

## License

This project is open source and available under the MIT License.

## Author

Created by Isa - Game Developer & Creative Designer
