from flask import Flask, render_template, redirect, url_for, send_from_directory
import webbrowser
import os

app = Flask(__name__)

# Game projects data with actual playable games
GAME_PROJECTS = [
    {
        'id': 1,
        'title': 'Snake Game',
        'description': 'Classic snake game - eat food and grow without hitting walls!',
        'play_link': '/games/snake.html',
        'source_link': '/source/snake.html',
        'python_source': 'snake.py',
        'tags': ['Classic', 'Arcade', 'Beginner-Friendly'],
        'icon': 'snake'
    },
    {
        'id': 2,
        'title': 'Hangman',
        'description': 'Guess the programming word letter by letter before the drawing completes',
        'play_link': '/games/hangman.html',
        'source_link': '/source/hangman.py',
        'python_source': 'hangman.py',
        'tags': ['Word Game', 'Educational', 'Logic'],
        'icon': 'hangman'
    },
    {
        'id': 3,
        'title': 'Calculator',
        'description': 'Full-featured calculator with history and keyboard support',
        'play_link': '/games/calculator.html',
        'source_link': '/source/calculator.py',
        'python_source': 'calculator.py',
        'tags': ['Utility', 'Math', 'Practical'],
        'icon': 'calculator'
    },
    {
        'id': 4,
        'title': 'Tic Tac Toe',
        'description': 'Classic 3x3 grid game - get three in a row to win!',
        'play_link': '/games/tictactoe.html',
        'source_link': '/source/tictactoe.py',
        'python_source': 'tictactoe.py',
        'tags': ['Strategy', 'Classic', 'Multiplayer'],
        'icon': 'tictactoe'
    },
    {
        'id': 5,
        'title': 'Number Guessing',
        'description': 'Guess the secret number with hints and multiple difficulty levels',
        'play_link': '/games/guess.html',
        'source_link': '/source/guess.py',
        'python_source': 'guess.py',
        'tags': ['Puzzle', 'Logic', 'Educational'],
        'icon': 'guess'
    },
    {
        'id': 6,
        'title': 'Rock Paper Scissors',
        'description': 'Classic hand game with score tracking and beautiful animations',
        'play_link': '/games/rps.html',
        'source_link': '/source/rps.py',
        'python_source': 'rps.py',
        'tags': ['Classic', 'Quick Play', 'Strategy'],
        'icon': 'rps'
    }
]

@app.route('/')
def index():
    return render_template('index.html', games=GAME_PROJECTS)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/games/<filename>')
def serve_game(filename):
    return send_from_directory('games', filename)

@app.route('/source/<filename>')
def serve_source(filename):
    try:
        with open(f'games/{filename}', 'r', encoding='utf-8') as file:
            source_code = file.read()
        
        return render_template('source_code.html', 
                             filename=filename, 
                             source_code=source_code,
                             game_title=filename.replace('.py', '').title())
    except FileNotFoundError:
        return "Source code not found", 404

@app.route('/game/<int:game_id>')
def game_detail(game_id):
    game = next((g for g in GAME_PROJECTS if g['id'] == game_id), None)
    if game:
        # Redirect to the play link
        return redirect(game['play_link'])
    return "Game not found", 404

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
