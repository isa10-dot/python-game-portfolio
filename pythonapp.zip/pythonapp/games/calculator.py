class Calculator:
    def __init__(self):
        self.history = []
    
    def add(self, a, b):
        result = a + b
        self.history.append(f"{a} + {b} = {result}")
        return result
    
    def subtract(self, a, b):
        result = a - b
        self.history.append(f"{a} - {b} = {result}")
        return result
    
    def multiply(self, a, b):
        result = a * b
        self.history.append(f"{a} × {b} = {result}")
        return result
    
    def divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero!")
        result = a / b
        self.history.append(f"{a} ÷ {b} = {result}")
        return result
    
    def power(self, a, b):
        result = a ** b
        self.history.append(f"{a} ^ {b} = {result}")
        return result
    
    def square_root(self, a):
        if a < 0:
            raise ValueError("Cannot calculate square root of negative number!")
        result = a ** 0.5
        self.history.append(f"√{a} = {result}")
        return result
    
    def show_history(self):
        if not self.history:
            print("No calculations yet.")
        else:
            print("\n📝 Calculator History:")
            print("-" * 30)
            for calculation in self.history[-10:]:  # Show last 10 calculations
                print(calculation)
    
    def clear_history(self):
        self.history.clear()
        print("History cleared!")

def get_number(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Please enter a valid number.")

def main():
    print("🧮 Welcome to Python Calculator!")
    print("=" * 40)
    
    calc = Calculator()
    
    while True:
        print("\nChoose an operation:")
        print("1. Addition (+)")
        print("2. Subtraction (-)")
        print("3. Multiplication (×)")
        print("4. Division (÷)")
        print("5. Power (^)")
        print("6. Square Root (√)")
        print("7. Show History")
        print("8. Clear History")
        print("9. Exit")
        
        choice = input("\nEnter your choice (1-9): ").strip()
        
        try:
            if choice == '1':
                a = get_number("Enter first number: ")
                b = get_number("Enter second number: ")
                result = calc.add(a, b)
                print(f"Result: {a} + {b} = {result}")
                
            elif choice == '2':
                a = get_number("Enter first number: ")
                b = get_number("Enter second number: ")
                result = calc.subtract(a, b)
                print(f"Result: {a} - {b} = {result}")
                
            elif choice == '3':
                a = get_number("Enter first number: ")
                b = get_number("Enter second number: ")
                result = calc.multiply(a, b)
                print(f"Result: {a} × {b} = {result}")
                
            elif choice == '4':
                a = get_number("Enter first number: ")
                b = get_number("Enter second number: ")
                result = calc.divide(a, b)
                print(f"Result: {a} ÷ {b} = {result}")
                
            elif choice == '5':
                a = get_number("Enter base number: ")
                b = get_number("Enter exponent: ")
                result = calc.power(a, b)
                print(f"Result: {a} ^ {b} = {result}")
                
            elif choice == '6':
                a = get_number("Enter number: ")
                result = calc.square_root(a)
                print(f"Result: √{a} = {result}")
                
            elif choice == '7':
                calc.show_history()
                
            elif choice == '8':
                calc.clear_history()
                
            elif choice == '9':
                print("Thank you for using Python Calculator! 👋")
                break
                
            else:
                print("Invalid choice. Please enter a number between 1-9.")
                
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()
