import random

class NumberGuessingGame:
    def __init__(self, difficulty='medium'):
        self.difficulties = {
            'easy': {'max': 50, 'attempts': 10},
            'medium': {'max': 100, 'attempts': 12},
            'hard': {'max': 500, 'attempts': 15}
        }
        self.difficulty = difficulty
        self.max_number = self.difficulties[difficulty]['max']
        self.max_attempts = self.difficulties[difficulty]['attempts']
        self.target_number = random.randint(1, self.max_number)
        self.attempts = 0
        self.guess_history = []
        self.hints_used = 0
    
    def make_guess(self, guess):
        if guess < 1 or guess > self.max_number:
            return f"Please enter a number between 1 and {self.max_number}"
        
        self.attempts += 1
        self.guess_history.append(guess)
        
        if guess == self.target_number:
            return f"🎉 Congratulations! You guessed it in {self.attempts} attempts!"
        elif self.attempts >= self.max_attempts:
            return f"💀 Game Over! The number was {self.target_number}"
        elif guess < self.target_number:
            difference = self.target_number - guess
            if difference <= 5:
                return "🔥 Very close! Go higher!"
            elif difference <= 20:
                return "📈 Close! Go higher!"
            else:
                return "⬆️ Too low! Go much higher!"
        else:
            difference = guess - self.target_number
            if difference <= 5:
                return "🔥 Very close! Go lower!"
            elif difference <= 20:
                return "📉 Close! Go lower!"
            else:
                return "⬇️ Too high! Go much lower!"
    
    def get_hint(self):
        if self.hints_used >= 2:
            return "No more hints available!"
        
        self.hints_used += 1
        
        if self.hints_used == 1:
            # Range hint
            lower_bound = max(1, self.target_number - 20)
            upper_bound = min(self.max_number, self.target_number + 20)
            return f"💡 Hint: The number is between {lower_bound} and {upper_bound}"
        else:
            # Even/odd hint
            return f"💡 Hint: The number is {'even' if self.target_number % 2 == 0 else 'odd'}"
    
    def is_game_over(self):
        return (self.attempts >= self.max_attempts or 
                self.target_number in self.guess_history)
    
    def get_status(self):
        return f"Attempts: {self.attempts}/{self.max_attempts} | Hints used: {self.hints_used}/2"

def get_valid_number(prompt, min_val, max_val):
    while True:
        try:
            number = int(input(prompt))
            if min_val <= number <= max_val:
                return number
            else:
                print(f"Please enter a number between {min_val} and {max_val}")
        except ValueError:
            print("Please enter a valid number")

def main():
    print("🎯 Welcome to Number Guessing Game!")
    print("=" * 40)
    
    while True:
        print("\nChoose difficulty:")
        print("1. Easy (1-50, 10 attempts)")
        print("2. Medium (1-100, 12 attempts)")
        print("3. Hard (1-500, 15 attempts)")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        difficulty_map = {'1': 'easy', '2': 'medium', '3': 'hard'}
        
        if choice not in difficulty_map:
            print("Invalid choice. Please enter 1, 2, or 3.")
            continue
        
        difficulty = difficulty_map[choice]
        game = NumberGuessingGame(difficulty)
        
        print(f"\n🎮 Starting {difficulty.capitalize()} mode!")
        print(f"I'm thinking of a number between 1 and {game.max_number}")
        print(f"You have {game.max_attempts} attempts. Good luck!")
        
        while not game.is_game_over():
            print(f"\n{game.get_status()}")
            print(f"Previous guesses: {game.guess_history}")
            
            print("\nOptions:")
            print("1. Make a guess")
            print("2. Get a hint")
            print("3. Quit game")
            
            option = input("Choose option (1-3): ").strip()
            
            if option == '1':
                guess = get_valid_number(
                    f"Enter your guess (1-{game.max_number}): ", 
                    1, 
                    game.max_number
                )
                result = game.make_guess(guess)
                print(result)
                
                if game.target_number in game.guess_history:
                    break
                elif game.attempts >= game.max_attempts:
                    break
                    
            elif option == '2':
                hint = game.get_hint()
                print(hint)
                
            elif option == '3':
                print(f"The number was {game.target_number}. Thanks for playing!")
                break
                
            else:
                print("Invalid option. Please enter 1, 2, or 3.")
        
        # Ask to play again
        play_again = input("\nWould you like to play again? (y/n): ").lower().strip()
        if play_again != 'y':
            print("Thanks for playing! 👋")
            break

if __name__ == "__main__":
    main()
