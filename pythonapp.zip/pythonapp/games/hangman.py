import random

class HangmanGame:
    def __init__(self):
        self.words = [
            'python', 'programming', 'computer', 'algorithm', 'function',
            'variable', 'string', 'integer', 'boolean', 'dictionary',
            'challenge', 'learning', 'practice', 'development', 'coding'
        ]
        self.word = random.choice(self.words).upper()
        self.guessed_letters = set()
        self.wrong_guesses = 0
        self.max_wrong_guesses = 6
        
    def get_display_word(self):
        return ' '.join([letter if letter in self.guessed_letters else '_' for letter in self.word])
    
    def guess_letter(self, letter):
        letter = letter.upper()
        if letter in self.guessed_letters:
            return "Already guessed!"
        
        self.guessed_letters.add(letter)
        
        if letter not in self.word:
            self.wrong_guesses += 1
            return f"Wrong! '{letter}' is not in the word."
        else:
            return f"Good! '{letter}' is in the word."
    
    def is_won(self):
        return all(letter in self.guessed_letters for letter in self.word)
    
    def is_lost(self):
        return self.wrong_guesses >= self.max_wrong_guesses
    
    def get_hangman_drawing(self):
        drawings = [
            "",
            "  +---+\n      |\n      |\n      |\n      |\n      |\n=========",
            "  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========",
            "  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n========="
        ]
        return drawings[self.wrong_guesses]

def main():
    print("🎮 Welcome to Hangman Game!")
    print("Guess the programming-related word letter by letter.")
    print("-" * 50)
    
    game = HangmanGame()
    
    while not game.is_won() and not game.is_lost():
        print(f"\nWord: {game.get_display_word()}")
        print(f"Wrong guesses: {game.wrong_guesses}/{game.max_wrong_guesses}")
        print(f"Guessed letters: {', '.join(sorted(game.guessed_letters))}")
        print(game.get_hangman_drawing())
        
        guess = input("\nEnter a letter: ").strip()
        
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single letter.")
            continue
            
        result = game.guess_letter(guess)
        print(result)
    
    print(game.get_hangman_drawing())
    if game.is_won():
        print(f"🎉 Congratulations! You guessed the word: {game.word}")
    else:
        print(f"💀 Game Over! The word was: {game.word}")

if __name__ == "__main__":
    main()
