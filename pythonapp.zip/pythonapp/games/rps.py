import random

class RockPaperScissors:
    def __init__(self):
        self.choices = ['rock', 'paper', 'scissors']
        self.player_score = 0
        self.computer_score = 0
        self.tie_score = 0
        self.game_history = []
        
    def get_computer_choice(self):
        return random.choice(self.choices)
    
    def determine_winner(self, player_choice, computer_choice):
        if player_choice == computer_choice:
            return 'tie'
        
        winning_combinations = {
            'rock': 'scissors',
            'paper': 'rock',
            'scissors': 'paper'
        }
        
        if winning_combinations[player_choice] == computer_choice:
            return 'player'
        else:
            return 'computer'
    
    def play_round(self, player_choice):
        if player_choice not in self.choices:
            return "Invalid choice! Please choose rock, paper, or scissors."
        
        computer_choice = self.get_computer_choice()
        winner = self.determine_winner(player_choice, computer_choice)
        
        # Update scores
        if winner == 'player':
            self.player_score += 1
        elif winner == 'computer':
            self.computer_score += 1
        else:
            self.tie_score += 1
        
        # Add to history
        self.game_history.append({
            'player': player_choice,
            'computer': computer_choice,
            'winner': winner
        })
        
        return {
            'player_choice': player_choice,
            'computer_choice': computer_choice,
            'winner': winner,
            'player_score': self.player_score,
            'computer_score': self.computer_score,
            'tie_score': self.tie_score
        }
    
    def get_scores(self):
        return {
            'player': self.player_score,
            'computer': self.computer_score,
            'ties': self.tie_score
        }
    
    def reset_game(self):
        self.player_score = 0
        self.computer_score = 0
        self.tie_score = 0
        self.game_history = []
    
    def show_history(self):
        if not self.game_history:
            return "No games played yet."
        
        history = "\n📝 Game History (Last 10 rounds):\n"
        history += "-" * 40 + "\n"
        
        for i, round_data in enumerate(self.game_history[-10:], 1):
            player = round_data['player'].title()
            computer = round_data['computer'].title()
            winner = round_data['winner']
            
            if winner == 'player':
                result = "You won! 🎉"
            elif winner == 'computer':
                result = "Computer won 🤖"
            else:
                result = "Tie 🤝"
            
            history += f"Round {len(self.game_history) - 10 + i}: {player} vs {computer} - {result}\n"
        
        return history

def get_player_choice():
    while True:
        choice = input("\nEnter your choice (rock/paper/scissors) or 'q' to quit: ").lower().strip()
        if choice in ['rock', 'paper', 'scissors', 'r', 'p', 's', 'q', 'quit']:
            if choice == 'r':
                return 'rock'
            elif choice == 'p':
                return 'paper'
            elif choice == 's':
                return 'scissors'
            elif choice in ['q', 'quit']:
                return 'quit'
            else:
                return choice
        else:
            print("Invalid input! Please enter rock, paper, scissors, or q to quit.")

def display_result(result):
    player_choice = result['player_choice'].title()
    computer_choice = result['computer_choice'].title()
    winner = result['winner']
    
    print(f"\n🎮 Round Result:")
    print(f"You chose: {player_choice}")
    print(f"Computer chose: {computer_choice}")
    
    if winner == 'player':
        print(f"🎉 You win! {player_choice} beats {computer_choice}!")
    elif winner == 'computer':
        print(f"😔 Computer wins! {computer_choice} beats {player_choice}!")
    else:
        print(f"🤝 It's a tie! Both chose {player_choice}!")
    
    print(f"\n📊 Current Score:")
    print(f"You: {result['player_score']} | Computer: {result['computer_score']} | Ties: {result['tie_score']}")

def main():
    print("✂️ Welcome to Rock Paper Scissors!")
    print("=" * 40)
    print("🎯 Rules:")
    print("• Rock crushes Scissors")
    print("• Scissors cuts Paper") 
    print("• Paper covers Rock")
    print("• First to 10 wins is the champion!")
    print("-" * 40)
    
    game = RockPaperScissors()
    
    while True:
        print("\nOptions:")
        print("1. Play a round")
        print("2. View game history")
        print("3. View current scores")
        print("4. Reset game")
        print("5. Exit")
        
        option = input("\nChoose an option (1-5): ").strip()
        
        if option == '1':
            player_choice = get_player_choice()
            if player_choice == 'quit':
                break
            
            result = game.play_round(player_choice)
            display_result(result)
            
            # Check for game end
            if game.player_score >= 10:
                print("\n🏆 CONGRATULATIONS! YOU ARE THE CHAMPION!")
                play_again = input("Would you like to play again? (y/n): ").lower().strip()
                if play_again == 'y':
                    game.reset_game()
                    print("🎮 New game started!")
                else:
                    break
            elif game.computer_score >= 10:
                print("\n🤖 COMPUTER WINS! Better luck next time!")
                play_again = input("Would you like to play again? (y/n): ").lower().strip()
                if play_again == 'y':
                    game.reset_game()
                    print("🎮 New game started!")
                else:
                    break
        
        elif option == '2':
            print(game.show_history())
        
        elif option == '3':
            scores = game.get_scores()
            print(f"\n📊 Current Scores:")
            print(f"You: {scores['player']}")
            print(f"Computer: {scores['computer']}")
            print(f"Ties: {scores['ties']}")
            print(f"Total rounds: {sum(scores.values())}")
        
        elif option == '4':
            game.reset_game()
            print("🔄 Game reset! Scores are back to 0-0-0")
        
        elif option == '5':
            print("Thanks for playing Rock Paper Scissors! 👋")
            break
        
        else:
            print("Invalid option. Please choose 1-5.")

if __name__ == "__main__":
    main()
