import random

class TicTacToe:
    def __init__(self):
        self.board = [' ' for _ in range(9)]
        self.current_player = 'X'
        
    def display_board(self):
        print("\n📋 Current Board:")
        print("-" * 13)
        for i in range(3):
            print(f"| {self.board[i*3]} | {self.board[i*3+1]} | {self.board[i*3+2]} |")
            print("-" * 13)
        
        print("\n📍 Position numbers:")
        print("-" * 13)
        for i in range(3):
            print(f"| {i*3+1} | {i*3+2} | {i*3+3} |")
            print("-" * 13)
    
    def make_move(self, position, player):
        if self.board[position] == ' ':
            self.board[position] = player
            return True
        return False
    
    def check_winner(self):
        # Check rows
        for i in range(0, 9, 3):
            if self.board[i] == self.board[i+1] == self.board[i+2] != ' ':
                return self.board[i]
        
        # Check columns
        for i in range(3):
            if self.board[i] == self.board[i+3] == self.board[i+6] != ' ':
                return self.board[i]
        
        # Check diagonals
        if self.board[0] == self.board[4] == self.board[8] != ' ':
            return self.board[0]
        if self.board[2] == self.board[4] == self.board[6] != ' ':
            return self.board[2]
        
        return None
    
    def is_board_full(self):
        return ' ' not in self.board
    
    def get_available_moves(self):
        return [i for i, spot in enumerate(self.board) if spot == ' ']
    
    def ai_move(self):
        """Simple AI that makes random moves"""
        available_moves = self.get_available_moves()
        if available_moves:
            return random.choice(available_moves)
        return None

def play_vs_human():
    game = TicTacToe()
    
    while True:
        game.display_board()
        
        # Get player move
        try:
            position = int(input(f"\n🎮 Player {game.current_player}, enter position (1-9): ")) - 1
            
            if position < 0 or position > 8:
                print("❌ Please enter a number between 1 and 9.")
                continue
                
            if not game.make_move(position, game.current_player):
                print("❌ That position is already taken!")
                continue
                
        except ValueError:
            print("❌ Please enter a valid number.")
            continue
        
        # Check for winner
        winner = game.check_winner()
        if winner:
            game.display_board()
            print(f"🎉 Player {winner} wins!")
            break
        
        if game.is_board_full():
            game.display_board()
            print("🤝 It's a draw!")
            break
        
        # Switch player
        game.current_player = 'O' if game.current_player == 'X' else 'X'

def play_vs_ai():
    game = TicTacToe()
    
    while True:
        game.display_board()
        
        if game.current_player == 'X':
            # Human player
            try:
                position = int(input(f"\n🎮 Your turn (X), enter position (1-9): ")) - 1
                
                if position < 0 or position > 8:
                    print("❌ Please enter a number between 1 and 9.")
                    continue
                    
                if not game.make_move(position, 'X'):
                    print("❌ That position is already taken!")
                    continue
                    
            except ValueError:
                print("❌ Please enter a valid number.")
                continue
        else:
            # AI player
            print("\n🤖 AI is thinking...")
            position = game.ai_move()
            if position is not None:
                game.make_move(position, 'O')
                print(f"🤖 AI chose position {position + 1}")
        
        # Check for winner
        winner = game.check_winner()
        if winner:
            game.display_board()
            if winner == 'X':
                print("🎉 You win! Great job!")
            else:
                print("🤖 AI wins! Better luck next time!")
            break
        
        if game.is_board_full():
            game.display_board()
            print("🤝 It's a draw!")
            break
        
        # Switch player
        game.current_player = 'O' if game.current_player == 'X' else 'X'

def main():
    print("⭕ Welcome to Tic Tac Toe!")
    print("=" * 30)
    
    while True:
        print("\nChoose game mode:")
        print("1. Play vs Human")
        print("2. Play vs AI")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            print("\n🎮 Starting Human vs Human game...")
            play_vs_human()
        elif choice == '2':
            print("\n🤖 Starting Human vs AI game...")
            play_vs_ai()
        elif choice == '3':
            print("Thanks for playing! 👋")
            break
        else:
            print("❌ Invalid choice. Please enter 1, 2, or 3.")
        
        # Ask if they want to play again
        if choice in ['1', '2']:
            play_again = input("\nWould you like to play again? (y/n): ").lower().strip()
            if play_again != 'y':
                print("Thanks for playing! 👋")
                break

if __name__ == "__main__":
    main()
